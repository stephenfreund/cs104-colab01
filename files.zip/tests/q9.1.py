test = {   'name': 'q9.1',
    'points': 5,
    'suites': [   {   'cases': [{'code': '>>> 0 <= biggest_change\nTrue', 'failure_message': 'biggest_change should be a non-negative number!', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
