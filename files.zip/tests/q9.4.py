test = {   'name': 'q9.4',
    'points': 5,
    'suites': [{'cases': [{'code': '>>> 1 <= biggest_rel_change_major <= 3\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
