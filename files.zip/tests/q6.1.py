test = {   'name': 'q6.1',
    'points': 5,
    'suites': [   {   'cases': [{'code': '>>> num_avenues_away == 3\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> manhattan_distance == 1462\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
