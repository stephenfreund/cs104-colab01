test = {   'name': 'q8.3',
    'points': 5,
    'suites': [   {   'cases': [{'code': '>>> 1 <= names_q3 <= 4\nTrue', 'failure_message': 'Be sure to set names_q1 to either 1, 2, or 3.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
