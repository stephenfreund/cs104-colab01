test = {   'name': 'q8.2',
    'points': 5,
    'suites': [   {   'cases': [{'code': '>>> 1 <= names_q2 <= 4\nTrue', 'failure_message': 'Be sure to set names_q2 to either 1, 2, or 3, 4.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
